# Candles (Pure CSS Animation)

A Pen created on CodePen.io. Original URL: [https://codepen.io/akhil_001/pen/mzNQoM](https://codepen.io/akhil_001/pen/mzNQoM).

Recreated the dribbble shot by Gal shir. in complete CSS Animations. Here is the link https://dribbble.com/shots/2516854-Candles .